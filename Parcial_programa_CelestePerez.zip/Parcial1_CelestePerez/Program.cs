﻿// See https://aka.ms/new-console-template for more information
using System.ComponentModel.Design;
using System.Globalization;

int opc;
int num1, num2,suma=0,resta=0,multi=0,divi=0,res=0;
int num3 = 0;
int valor1, valor2;
const double pi = 3.1416;
int radio;
double area;
string nombre, apellid;
int edad, i=0;
string contr = "tarea";
bool Sn = true;
string n1, n2,n3;

do
{
    Console.WriteLine("Menú");
    Console.WriteLine("1.Expresiones aritméticas");
    Console.WriteLine("2.Operadores de incremento y decremento");
    Console.WriteLine("3.Operadores relacionales");
    Console.WriteLine("4.operadores logicos");
    Console.WriteLine("5.Uso de contantes");
    Console.WriteLine("6.Concatenación");
    Console.WriteLine("7.Bucles");
    Console.WriteLine("8.Salir");
    opc = Int32.Parse(Console.ReadLine());


    switch (opc)
    {
        case 1:
            Console.WriteLine("Ingrese el primer numero: ");
            num1 = Int32.Parse(Console.ReadLine());
            Console.WriteLine("ingrese el segundo numero");
            num2 = Int32.Parse(Console.ReadLine());

            suma = num1 + num2;
            Console.WriteLine("La suma de los numeros es: " + suma);

            resta = num1 - num2;
            Console.WriteLine("L resta de los numeros es: " + resta);

            multi = num1 * num2;
            Console.WriteLine("La multiplicación de los numeros es: " + multi);

            divi = num1 / num2;
            Console.WriteLine("la división de los numeros es: " + divi);

            res = num1 % num2;
            Console.WriteLine("El residuo de los numeros es: " + res);
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            break;

        case 2:
            Console.WriteLine("Ingrese un numero: ");
            num3 = Int32.Parse(Console.ReadLine());

            num3++;
            Console.WriteLine("El valor de incremento del numero es: " + num3);

            num3--;
            Console.WriteLine("El valor de decremento es: " + num3);
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            break;

        case 3:
            Console.WriteLine("Ingrese el primer valor");
            valor1 = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el segundo valor");
            valor2 = Int32.Parse(Console.ReadLine());

            if (valor1 == valor2)
            {
                Console.WriteLine("Los valores son iguales");
            } else if (valor1 != valor2)
            {
                Console.WriteLine("Los valores son distintos");
            }
            else if (valor1 > valor2)
            {
                Console.WriteLine($"El primer valor {valor1} es mayor que el segundo {valor2}");
            }
            else if (valor1 < valor2)
            {
                Console.WriteLine($"El primer valor {valor1} es menor que el segundo {valor2}");
            }
            else if (valor1 >= valor2)
            {
                Console.WriteLine("El primer valor es mayor o igual al segundo valor");
            }
            else if (valor1 <= valor2)
            {
                Console.WriteLine("El primer valor menor o igual al segundo valor");
            }
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            break;
        case 4:
            Console.WriteLine("Ingrese operador 1:");
            n1 = Console.ReadLine();
            Console.WriteLine("Ingrese operador 2:");
            n2 = Console.ReadLine();    
            Console.WriteLine("Ingrese operador 3:");
            n3= Console.ReadLine();





            Console.WriteLine("\n");
            Console.WriteLine("\n");
            break;
        case 5:
            try
            {
                Console.WriteLine("Ingrese el radio: ");
                radio = Int32.Parse(Console.ReadLine());

                area = (radio * radio) * pi;
                Console.WriteLine("El área del circulo es: " + area);
                Console.WriteLine("\n");
                Console.WriteLine("\n");
            }catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            break;
        case 6:
            Console.WriteLine("Ingrese su nombre: ");
            nombre = Console.ReadLine();
            Console.WriteLine("Ingrese su apellido: ");
            apellid = Console.ReadLine();
            Console.WriteLine("Ingrese su edad: ");
            edad = Int32.Parse(Console.ReadLine());

            Console.WriteLine("Sus datos son: "+ nombre+"  "+apellid+" "+ edad);
            Console.WriteLine($"Su nombre es {nombre} su apellido es {apellid} y tienen {edad} de edad");

            Console.WriteLine("\n");
            Console.WriteLine("\n");
            break;
        case 7:
            Console.WriteLine("Datos del 1 al 10: ");
            for (i=0;i < 11; i++)
            {
                Console.WriteLine(i);
            }

            //la clave es: tarea
            while (Sn)
            {
                Console.WriteLine("Ingrese la clave: ");
                contr = Console.ReadLine();
           
                if (contr.Equals("tarea"))
                {
                    Console.WriteLine("Acceso concedido");
                    Sn = false;
                }
                else
                {
                    Console.WriteLine("Clave incorrecta");
                     Sn= true;
                }
            }

            break;
        case 8:
            Console.WriteLine("Finalizar programa");
            break;
    }
} while (opc != 8);